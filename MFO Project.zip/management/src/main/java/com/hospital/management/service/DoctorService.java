package com.hospital.management.service;

import com.hospital.management.model.Doctor;
import com.hospital.management.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    // ✅ Add Doctor
    public void addDoctor(Doctor doctor) {
        doctorRepository.save(doctor);
    }

    // ✅ Get All Doctors with Pagination
    public List<Doctor> getAllDoctors(int page, int size) {
        return doctorRepository.findAll(page, size);
    }

    // ✅ Get Doctor by ID
    public Doctor getDoctorById(int id) {
        return doctorRepository.findById(id);
    }

    // ✅ Update Doctor
    public void updateDoctor(Doctor doctor) {
        doctorRepository.update(doctor);
    }

    // ✅ Delete Doctor
    public void deleteDoctor(int id) {
        doctorRepository.deleteById(id);
    }

    // ✅ Group by Specialization
    public List<Map<String, Object>> groupBySpecialization() {
        return doctorRepository.groupBySpecialization();
    }
}

