package com.hospital.management.repository;

import com.hospital.management.model.Doctor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class DoctorRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public DoctorRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // ✅ Create (Insert) Doctor
    public void save(Doctor doctor) {
        String sql = "INSERT INTO doctor (name, specialization, contact) VALUES (:name, :specialization, :contact)";
        Map<String, Object> params = new HashMap<>();
        params.put("name", doctor.getName());
        params.put("specialization", doctor.getSpecialization());
        params.put("contact", doctor.getContact());
        jdbcTemplate.update(sql, params);
    }

    // ✅ Read (Get All Doctors with Pagination)
    public List<Doctor> findAll(int page, int size) {
        String sql = "SELECT * FROM doctor LIMIT :size OFFSET :offset";
        Map<String, Object> params = new HashMap<>();
        params.put("size", size);
        params.put("offset", (page - 1) * size);
        return jdbcTemplate.query(sql, params, doctorRowMapper);
    }

    // ✅ Read by ID
    public Doctor findById(int id) {
        String sql = "SELECT * FROM doctor WHERE id = :id";
        Map<String, Object> params = Map.of("id", id);
        return jdbcTemplate.queryForObject(sql, params, doctorRowMapper);
    }

    // ✅ Update Doctor
    public void update(Doctor doctor) {
        String sql = "UPDATE doctor SET name = :name, specialization = :specialization, contact = :contact WHERE id = :id";
        Map<String, Object> params = new HashMap<>();
        params.put("id", doctor.getId());
        params.put("name", doctor.getName());
        params.put("specialization", doctor.getSpecialization());
        params.put("contact", doctor.getContact());
        jdbcTemplate.update(sql, params);
    }

    // ✅ Delete Doctor by ID
    public void deleteById(int id) {
        String sql = "DELETE FROM doctor WHERE id = :id";
        Map<String, Object> params = Map.of("id", id);
        jdbcTemplate.update(sql, params);
    }

    // ✅ Group by Specialization
    public List<Map<String, Object>> groupBySpecialization() {
        String sql = "SELECT specialization, COUNT(*) AS doctor_count FROM doctor GROUP BY specialization";
        return jdbcTemplate.queryForList(sql, new HashMap<>());
    }

    // ✅ RowMapper for Doctor
    private final RowMapper<Doctor> doctorRowMapper = (rs, rowNum) -> {
        Doctor doctor = new Doctor();
        doctor.setId(rs.getInt("id"));
        doctor.setName(rs.getString("name"));
        doctor.setSpecialization(rs.getString("specialization"));
        doctor.setContact(rs.getString("contact"));
        return doctor;
    };
}
