package com.hospital.management.repository;

import com.hospital.management.model.Appointment;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class AppointmentRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public AppointmentRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // ✅ Insert a new appointment
    public void save(Appointment appointment) {
        String sql = """
            INSERT INTO appointment (patient_id, doctor_id, date, time, status)
            VALUES (:patient_id, :doctor_id, :date, :time, :status)
        """;

        Map<String, Object> params = new HashMap<>();
        params.put("patient_id", appointment.getPatientId());
        params.put("doctor_id", appointment.getDoctorId());
        params.put("date", appointment.getDate());
        params.put("time", appointment.getTime());
        params.put("status", appointment.getStatus());

        jdbcTemplate.update(sql, params);
    }

    // ✅ Get all appointments with pagination
    public List<Appointment> findAll(int page, int size) {
        String sql = """
            SELECT * FROM appointment
            LIMIT :size OFFSET :offset
        """;

        Map<String, Object> params = new HashMap<>();
        params.put("size", size);
        params.put("offset", (page - 1) * size);

        return jdbcTemplate.query(sql, params, appointmentRowMapper);
    }

    // ✅ Get appointment by ID
    public Appointment findById(int id) {
        String sql = "SELECT * FROM appointment WHERE id = :id";
        Map<String, Object> params = Map.of("id", id);
        return jdbcTemplate.queryForObject(sql, params, appointmentRowMapper);
    }

    // ✅ Update appointment
    public void update(Appointment appointment) {
        String sql = """
            UPDATE appointment
            SET patient_id = :patient_id, doctor_id = :doctor_id, date = :date, time = :time, status = :status
            WHERE id = :id
        """;

        Map<String, Object> params = new HashMap<>();
        params.put("id", appointment.getId());
        params.put("patient_id", appointment.getPatientId());
        params.put("doctor_id", appointment.getDoctorId());
        params.put("date", appointment.getDate());
        params.put("time", appointment.getTime());
        params.put("status", appointment.getStatus());

        jdbcTemplate.update(sql, params);
    }

    // ✅ Delete appointment by ID
    public void deleteById(int id) {
        String sql = "DELETE FROM appointment WHERE id = :id";
        Map<String, Object> params = Map.of("id", id);
        jdbcTemplate.update(sql, params);
    }

    // ✅ Group appointments by doctor_id with pagination
    public List<Map<String, Object>> groupByDoctor(int page, int size) {
        String sql = """
            SELECT doctor_id, COUNT(*) AS total_appointments
            FROM appointment
            GROUP BY doctor_id
            LIMIT :size OFFSET :offset
        """;

        Map<String, Object> params = new HashMap<>();
        params.put("size", size);
        params.put("offset", (page - 1) * size);

        return jdbcTemplate.queryForList(sql, params);
    }

    // ✅ RowMapper for Appointment
    private final RowMapper<Appointment> appointmentRowMapper = (rs, rowNum) -> {
        Appointment appointment = new Appointment();
        appointment.setId(rs.getInt("id"));
        appointment.setPatientId(rs.getInt("patient_id"));
        appointment.setDoctorId(rs.getInt("doctor_id"));
        appointment.setDate(rs.getDate("date").toLocalDate());
        appointment.setTime(rs.getTime("time").toLocalTime());
        appointment.setStatus(rs.getString("status"));
        return appointment;
    };
}

