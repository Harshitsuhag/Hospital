package com.hospital.management.service;

import com.hospital.management.model.Appointment;
import com.hospital.management.repository.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;

    public AppointmentService(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    // ✅ Add a new appointment
    public void addAppointment(Appointment appointment) {
        appointmentRepository.save(appointment);
    }

    // ✅ Get all appointments with pagination
    public List<Appointment> getAllAppointments(int page, int size) {
        return appointmentRepository.findAll(page, size);
    }

    // ✅ Get appointment by ID
    public Appointment getAppointmentById(int id) {
        return appointmentRepository.findById(id);
    }

    // ✅ Update appointment
    public void updateAppointment(Appointment appointment) {
        appointmentRepository.update(appointment);
    }

    // ✅ Delete appointment
    public void deleteAppointment(int id) {
        appointmentRepository.deleteById(id);
    }

    // ✅ Get grouped appointments by doctor_id with pagination
    public List<Map<String, Object>> getAppointmentsGroupedByDoctor(int page, int size) {
        return appointmentRepository.groupByDoctor(page, size);
    }
}
