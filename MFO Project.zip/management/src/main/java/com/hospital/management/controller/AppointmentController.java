package com.hospital.management.controller;

import com.hospital.management.model.Appointment;
import com.hospital.management.service.AppointmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/appointments")  // ✅ Correct base URL
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    // ✅ Create a new appointment
    @PostMapping
    public ResponseEntity<String> createAppointment(@RequestBody Appointment appointment) {
        appointmentService.addAppointment(appointment);
        return ResponseEntity.ok("Appointment created successfully!");
    }

    // ✅ Get all appointments with pagination
    @GetMapping
    public List<Appointment> getAppointments(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size) {
        return appointmentService.getAllAppointments(page, size);
    }

    // ✅ Get appointment by ID
    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable int id) {
        Appointment appointment = appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(appointment);
    }

    // ✅ Update appointment by ID
    @PutMapping("/{id}")
    public ResponseEntity<String> updateAppointment(@PathVariable int id, @RequestBody Appointment appointment) {
        appointment.setId(id);
        appointmentService.updateAppointment(appointment);
        return ResponseEntity.ok("Appointment updated successfully!");
    }

    // ✅ Delete appointment by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAppointment(@PathVariable int id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.ok("Appointment deleted successfully!");
    }

    // ✅ Group appointments by doctor_id with pagination
    @GetMapping("/group-by-doctor")
    public List<Map<String, Object>> getAppointmentsGroupedByDoctor(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size) {
        return appointmentService.getAppointmentsGroupedByDoctor(page, size);
    }
}
