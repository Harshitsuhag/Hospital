package com.hospital.management.controller;

import com.hospital.management.model.Patient;
import com.hospital.management.service.PatientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @PostMapping
    public ResponseEntity<String> createPatient(@RequestBody Patient patient) {
        patientService.addPatient(patient);
        return ResponseEntity.ok("Patient added successfully");
    }

    @GetMapping
    public ResponseEntity<List<Patient>> getPatients(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "5") int size) {

        List<Patient> patients = patientService.getAllPatients(page, size);
        return ResponseEntity.ok(patients);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable int id) {
        Optional<Patient> patient = patientService.getPatientByIdOptional(id);

        return patient.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());   
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updatePatient(@PathVariable int id, @RequestBody Patient patient) {
        Optional<Patient> updatedPatient = patientService.updatePatient(id, patient);

        if (updatedPatient.isPresent()) {
            return ResponseEntity.ok("Patient updated successfully");
        } else {
            return ResponseEntity.status(404).body("Patient not found with ID: " + id);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePatient(@PathVariable int id) {
        boolean deleted = patientService.deletePatient(id);

        if (deleted) {
            return ResponseEntity.ok("Patient deleted successfully");
        } else {
            return ResponseEntity.status(404).body("Patient not found with ID: " + id);
        }
    }
}

