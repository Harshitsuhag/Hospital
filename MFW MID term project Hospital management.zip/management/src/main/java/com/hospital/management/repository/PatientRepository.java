package com.hospital.management.repository;

import com.hospital.management.model.Patient;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class PatientRepository {

    private final JdbcTemplate jdbcTemplate;

    public PatientRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void save(Patient patient) {
        String sql = "INSERT INTO patient (name, age, gender, contact) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, patient.getName(), patient.getAge(), patient.getGender(), patient.getContact());
    }

    public List<Patient> findAll(int offset, int size) {
        String sql = "SELECT * FROM patient LIMIT ? OFFSET ?";
        return jdbcTemplate.query(sql, this::mapRowToPatient, size, offset);
    }

    public Optional<Patient> findById(int id) {
        String sql = "SELECT * FROM patient WHERE id = ?";
        List<Patient> patients = jdbcTemplate.query(sql, this::mapRowToPatient, id);
        return patients.stream().findFirst();
    }

    public void update(int id, Patient patient) {
        String sql = "UPDATE patient SET name = ?, age = ?, gender = ?, contact = ? WHERE id = ?";
        jdbcTemplate.update(sql, patient.getName(), patient.getAge(), patient.getGender(), patient.getContact(), id);
    }

    public void delete(int id) {
        String sql = "DELETE FROM patient WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }

    private Patient mapRowToPatient(ResultSet rs, int rowNum) throws SQLException {
        Patient patient = new Patient();
        patient.setId(rs.getInt("id"));
        patient.setName(rs.getString("name"));
        patient.setAge(rs.getInt("age"));
        patient.setGender(rs.getString("gender"));
        patient.setContact(rs.getString("contact"));
        return patient;
    }
}
