package com.hospital.management.service;

import com.hospital.management.model.Patient;
import com.hospital.management.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public Patient addPatient(Patient patient) {
        patientRepository.save(patient);
        return patient;
    }

    public List<Patient> getAllPatients(int page, int size) {
        return patientRepository.findAll(page, size);
    }

    public Optional<Patient> getPatientByIdOptional(int id) {
        return patientRepository.findById(id);
    }

    public Optional<Patient> updatePatient(int id, Patient updatedPatient) {
        Optional<Patient> optionalPatient = getPatientByIdOptional(id);

        if (optionalPatient.isPresent()) {
            Patient existingPatient = optionalPatient.get();
            
            existingPatient.setName(updatedPatient.getName());
            existingPatient.setAge(updatedPatient.getAge());
            existingPatient.setGender(updatedPatient.getGender());
            existingPatient.setContact(updatedPatient.getContact());

            patientRepository.update(id, existingPatient);
            return Optional.of(existingPatient);
        } else {
            return Optional.empty(); 
        }
    }

    public boolean deletePatient(int id) {
        Optional<Patient> optionalPatient = getPatientByIdOptional(id);
        
        if (optionalPatient.isPresent()) {
            patientRepository.delete(id);
            return true;
        }
        return false;  
    }
}
