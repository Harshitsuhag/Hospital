package com.hospital.management.controller;

import com.hospital.management.model.Doctor;
import com.hospital.management.service.DoctorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @PostMapping
    public ResponseEntity<String> addDoctor(@RequestBody Doctor doctor) {
        doctorService.addDoctor(doctor);
        return ResponseEntity.ok("Doctor added successfully!");
    }

    @GetMapping
    public List<Doctor> getDoctors(@RequestParam int page, @RequestParam int size) {
        return doctorService.getAllDoctors(page, size);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable int id) {
        Doctor doctor = doctorService.getDoctorById(id);
        return ResponseEntity.ok(doctor);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateDoctor(@PathVariable int id, @RequestBody Doctor doctor) {
        doctor.setId(id);
        doctorService.updateDoctor(doctor);
        return ResponseEntity.ok("Doctor updated successfully!");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDoctor(@PathVariable int id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.ok("Doctor deleted successfully!");
    }

    @GetMapping("/group-by-specialization")
    public List<Map<String, Object>> groupBySpecialization() {
        return doctorService.groupBySpecialization();
    }
}
