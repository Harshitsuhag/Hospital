package com.hospital.hospital_management.controller;

import com.hospital.hospital_management.services.PatientService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/patients")
class PatientController {
    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @PostMapping
    public String addPatient(@RequestBody Map<String, Object> patient) {
        patientService.addPatient(patient);
        return "Patient added";
    }

    @GetMapping
    public List<Map<String, Object>> getPatients(@RequestParam(defaultValue = "1") int page,
                                                 @RequestParam(defaultValue = "5") int size) {
        return patientService.getPatients(page, size);
    }

    @DeleteMapping("/{id}")
    public String deletePatient(@PathVariable int id) {
        patientService.deletePatient(id);
        return "Patient deleted";
    }
}