package com.hospital.hospital_management.services;
import com.hospital.hospital_management.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DoctorService {
    public final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public void addDoctor(Map<String, Object> doctor) {
        doctorRepository.addDoctor(doctor);
    }

    public List<Map<String, Object>> getDoctors() {
        return doctorRepository.getDoctors();
    }
}