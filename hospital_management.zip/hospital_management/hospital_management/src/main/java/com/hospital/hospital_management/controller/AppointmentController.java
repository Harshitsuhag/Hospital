package com.hospital.hospital_management.controller;

import com.hospital.hospital_management.services.AppointmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/appointments")
class AppointmentController {
    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @PostMapping
    public String addAppointment(@RequestBody Map<String, Object> appointment) {
        appointmentService.addAppointment(appointment);
        return "Appointment added";
    }

    @GetMapping("/group-by-doctor")
    public List<Map<String, Object>> getAppointmentsGroupedByDoctor() {
        return appointmentService.getAppointmentsGroupedByDoctor();
    }
}
