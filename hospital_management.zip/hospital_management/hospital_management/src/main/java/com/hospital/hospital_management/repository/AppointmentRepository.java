package com.hospital.hospital_management.repository;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AppointmentRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public AppointmentRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void addAppointment(Map<String, Object> appointment) {
        String sql = "INSERT INTO appointments (patient_id, doctor_id, date) VALUES (:patient_id, :doctor_id, :date)";
        jdbcTemplate.update(sql, appointment);
    }

    public List<Map<String, Object>> getAppointments() {
        return jdbcTemplate.queryForList("SELECT * FROM appointments", Map.of());
    }
}