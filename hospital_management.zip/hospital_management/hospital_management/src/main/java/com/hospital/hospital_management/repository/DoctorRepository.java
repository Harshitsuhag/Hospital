package com.hospital.hospital_management.repository;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class DoctorRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public DoctorRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void addDoctor(Map<String, Object> doctor) {
        String sql = "INSERT INTO doctors (name, specialty) VALUES (:name, :specialty)";
        jdbcTemplate.update(sql, doctor);
    }

    public List<Map<String, Object>> getDoctors() {
        return jdbcTemplate.queryForList("SELECT * FROM doctors", Map.of());
    }
}
