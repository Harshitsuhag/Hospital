package com.hospital.hospital_management.repository;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class PatientRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public PatientRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void addPatient(Map<String, Object> patient) {
        String sql = "INSERT INTO patients (name, age, disease) VALUES (:name, :age, :disease)";
        jdbcTemplate.update(sql, patient);
    }

    public List<Map<String, Object>> getPatients(int page, int size) {
        int offset = (page - 1) * size;
        String sql = "SELECT * FROM patients LIMIT :size OFFSET :offset";
        return jdbcTemplate.queryForList(sql, Map.of("size", size, "offset", offset));
    }

    public void deletePatient(int id) {
        jdbcTemplate.update("DELETE FROM patients WHERE id = :id", Map.of("id", id));
    }
}
