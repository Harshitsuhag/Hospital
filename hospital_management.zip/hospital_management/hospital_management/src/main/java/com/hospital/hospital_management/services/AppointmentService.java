package com.hospital.hospital_management.services;
import com.hospital.hospital_management.repository.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AppointmentService {
    private final AppointmentRepository appointmentRepository;

    public AppointmentService(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    public void addAppointment(Map<String, Object> appointment) {
        appointmentRepository.addAppointment(appointment);
    }

    public List<Map<String, Object>> getAppointmentsGroupedByDoctor() {
        List<Map<String, Object>> result = appointmentRepository.getAppointments();
        return result.stream().collect(Collectors.groupingBy(a -> (Integer) a.get("doctor_id"))).values().stream().flatMap(Collection::stream).toList();
    }
}