package com.hospital.hospital_management.controller;

//import com.hospital.hospital_management.services.DoctorService;
import com.hospital.hospital_management.services.DoctorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/doctors")
class DoctorController {
    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @PostMapping
    public String addDoctor(@RequestBody Map<String, Object> doctor) {
        doctorService.addDoctor(doctor);
        return "Doctor added";
    }

    @GetMapping
    public List<Map<String, Object>> getDoctors() {
        return doctorService.getDoctors();
    }
}
