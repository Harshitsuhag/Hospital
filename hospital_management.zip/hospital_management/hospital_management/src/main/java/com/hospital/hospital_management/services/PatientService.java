package com.hospital.hospital_management.services;

import com.hospital.hospital_management.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PatientService {
    public final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public void addPatient(Map<String, Object> patient) {
        patientRepository.addPatient(patient);
    }

    public List<Map<String, Object>> getPatients(int page, int size) {
        return patientRepository.getPatients(page, size);
    }

    public void deletePatient(int id) {
        patientRepository.deletePatient(id);
    }
}
